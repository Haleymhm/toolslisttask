jquery-alert
============

jquery alert will easy for alert message
